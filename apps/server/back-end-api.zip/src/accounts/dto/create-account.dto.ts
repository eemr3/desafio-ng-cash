export class CreateAccountDto {
  balance?: number;
}
